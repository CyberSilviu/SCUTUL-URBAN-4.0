var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/seismic.js
var seismic_exports = {};
__export(seismic_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(seismic_exports);
async function handler(event) {
  const { net, sta, loc, cha, start, end } = event.queryStringParameters || {};
  if (!sta || !start || !end) {
    return json400({ error: "Parametri lips\u0103: sta, start, end" });
  }
  const url = `https://data.raspberryshake.org/fdsnws/dataselect/1/query?net=${net || "AM"}&sta=${sta}&loc=${loc || "00"}&cha=${cha || "EHZ"}&start=${start}&end=${end}`;
  let resp;
  try {
    resp = await fetch(url, { headers: { "User-Agent": "SeismicWatch/1.0" } });
  } catch (err) {
    return json500({ error: "Network error: " + err.message });
  }
  if (!resp.ok) {
    return {
      statusCode: resp.status,
      headers: corsHeaders(),
      body: JSON.stringify({ error: `FDSN ${resp.status}: ${resp.statusText}` })
    };
  }
  const buf = Buffer.from(await resp.arrayBuffer());
  let samples, sampleRate, startTime;
  try {
    ({ samples, sampleRate, startTime } = decodeMiniSEED(buf));
  } catch (err) {
    return json500({ error: "Decode error: " + err.message });
  }
  if (!samples.length) {
    return json500({ error: "No samples decoded" });
  }
  const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
  const detrended = samples.map((s) => s - mean);
  const filtered = butterworthBandpass(detrended, sampleRate, 0.5, 4, 4);
  const classification = classifySource(detrended, filtered, sampleRate);
  return {
    statusCode: 200,
    headers: { ...corsHeaders(), "Content-Type": "application/json" },
    body: JSON.stringify({
      samples: detrended,
      // semnal original detrended
      filtered,
      // semnal filtrat 0.5-4 Hz
      sampleRate,
      startTime,
      count: detrended.length,
      classification
      // analiza sursa
    })
  };
}
function butterworthBandpass(signal, fs, fLow, fHigh, order = 4) {
  const sections = designButterworthBP(fs, fLow, fHigh, order);
  let y = applyBiquadCascade(signal, sections);
  y.reverse();
  y = applyBiquadCascade(y, sections);
  y.reverse();
  return y;
}
function designButterworthBP(fs, fLow, fHigh, order) {
  const nyq = fs / 2;
  const wLow = Math.tan(Math.PI * fLow / fs);
  const wHigh = Math.tan(Math.PI * fHigh / fs);
  const bw = wHigh - wLow;
  const w0sq = wLow * wHigh;
  const sections = [];
  const nPairs = Math.floor(order / 2);
  for (let k = 1; k <= nPairs; k++) {
    const theta = Math.PI * (2 * k - 1) / (2 * order);
    const sinT = Math.sin(theta);
    const cosT = Math.cos(theta);
    const alpha = bw * sinT / 2;
    const beta = Math.sqrt(w0sq + (bw * sinT / 2) ** 2);
    const a0 = 1 + alpha;
    const a1 = -2 * Math.cos(2 * Math.PI * Math.sqrt(w0sq) / (2 * Math.PI));
    const a2 = 1 - alpha;
    const Wn = 2 * Math.atan(Math.sqrt(w0sq)) / Math.PI * (fs / 2);
    const Q = Math.sqrt(w0sq) / bw;
    const w0d = 2 * Math.PI * Math.sqrt(fLow * fHigh) / fs;
    const alph = Math.sin(w0d) / (2 * Q);
    sections.push({
      b0: alph,
      b1: 0,
      b2: -alph,
      a0: 1 + alph,
      a1: -2 * Math.cos(w0d),
      a2: 1 - alph
    });
  }
  if (order % 2 !== 0) {
    const wc = Math.tan(Math.PI * Math.sqrt(fLow * fHigh) / fs);
    sections.push({ b0: wc, b1: 0, b2: 0, a0: 1 + wc, a1: -(1 - wc), a2: 0 });
  }
  return sections;
}
function applyBiquadCascade(signal, sections) {
  let y = Float64Array.from(signal);
  for (const s of sections) {
    const { b0, b1, b2, a0, a1, a2 } = s;
    const B0 = b0 / a0, B1 = b1 / a0, B2 = b2 / a0;
    const A1 = a1 / a0, A2 = a2 / a0;
    const out = new Float64Array(y.length);
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < y.length; i++) {
      const x0 = y[i];
      const y0 = B0 * x0 + B1 * x1 + B2 * x2 - A1 * y1 - A2 * y2;
      out[i] = y0;
      x2 = x1;
      x1 = x0;
      y2 = y1;
      y1 = y0;
    }
    y = out;
  }
  return Array.from(y);
}
function classifySource(raw, filtered, fs) {
  const n = raw.length;
  if (n === 0) return { type: "unknown", confidence: 0, details: {} };
  const fftSize = nextPow2(Math.min(n, 8192));
  const re = new Float64Array(fftSize);
  const im = new Float64Array(fftSize);
  for (let i = 0; i < fftSize; i++) {
    const w = 0.5 * (1 - Math.cos(2 * Math.PI * i / (fftSize - 1)));
    re[i] = (raw[n - fftSize + i] || 0) * w;
  }
  fftInPlace(re, im);
  let pSeismic = 0, pTraffic = 0, pIndustrial = 0, pTotal = 0;
  let pInfrasonic = 0, pAllTotal = 0;
  for (let i = 1; i < fftSize / 2; i++) {
    const f = i * fs / fftSize;
    const mag = re[i] * re[i] + im[i] * im[i];
    if (f >= 0.5 && f <= 4.5) pSeismic += mag;
    if (f > 4.5 && f <= 15) pTraffic += mag;
    if (f > 15 && f <= 45) pIndustrial += mag;
    if (f >= 0.5 && f <= 45) pTotal += mag;
    if (f < 0.5) pInfrasonic += mag;
    pAllTotal += mag;
  }
  pTotal = pTotal || 1;
  pAllTotal = pAllTotal || 1;
  const ratioSeismic = pSeismic / pTotal;
  const ratioTraffic = pTraffic / pTotal;
  const ratioIndustrial = pIndustrial / pTotal;
  const ratioInfrasonic = pInfrasonic / pAllTotal;
  const env = computeEnvelope(raw, fs);
  const peakV = Math.max(...env);
  const peakI = env.indexOf(peakV);
  let iRise10 = 0, iRise90 = peakI;
  for (let i = 0; i < peakI; i++) {
    if (env[i] > peakV * 0.1 && iRise10 === 0) iRise10 = i;
    if (env[i] > peakV * 0.9) {
      iRise90 = i;
      break;
    }
  }
  const riseTimeSec = Math.max(0, iRise90 - iRise10) / fs;
  let evSamples = 0;
  for (const v of env) if (v > peakV * 0.1) evSamples++;
  const eventDuration = evSamples / fs;
  let prePeak = 0, postPeak = 0;
  for (let i = 0; i < peakI; i++) prePeak += env[i] * env[i];
  for (let i = peakI + 1; i < env.length; i++) postPeak += env[i] * env[i];
  const codaRatio = prePeak > 0 ? postPeak / prePeak : 1;
  const asymmetry = postPeak / (prePeak + postPeak + 1e-10);
  const staLta = computeSTALTA(raw, fs);
  const rms = Math.sqrt(raw.reduce((a, b) => a + b * b, 0) / n);
  const impulsivity = peakV / (rms + 1e-10);
  const segSamples = Math.round(fs * 5);
  const nSegs = Math.floor(n / segSamples);
  let seismicInSeg = 0;
  for (let s = 0; s < Math.min(nSegs, 6); s++) {
    const seg = raw.slice(s * segSamples, (s + 1) * segSamples);
    const segRms = Math.sqrt(seg.reduce((a, b) => a + b * b, 0) / seg.length);
    const segPeak = Math.max(...seg.map(Math.abs));
    if (segRms > rms * 0.3) seismicInSeg++;
  }
  const spectralPersistence = nSegs > 0 ? seismicInSeg / Math.min(nSegs, 6) : 0;
  let score = 0;
  const flags = [];
  if (ratioSeismic > 0.55) {
    score += 3;
    flags.push("spectru seismic dominant");
  } else if (ratioSeismic > 0.35) {
    score += 1;
    flags.push("spectru partial seismic");
  }
  if (ratioTraffic > 0.45) {
    score -= 3;
    flags.push("energie trafic ridicata");
  }
  if (ratioIndustrial > 0.35) {
    score -= 2;
    flags.push("zgomot industrial");
  }
  if (riseTimeSec > 5) {
    score += 3;
    flags.push(`rise time lung (${riseTimeSec.toFixed(1)}s)`);
  } else if (riseTimeSec > 2) {
    score += 1;
    flags.push(`rise time mediu (${riseTimeSec.toFixed(1)}s)`);
  } else if (riseTimeSec < 0.8) {
    score -= 4;
    flags.push(`rise time SCURT (${riseTimeSec.toFixed(2)}s) \u2014 probabil trafic`);
  } else if (riseTimeSec < 1.5) {
    score -= 2;
    flags.push(`rise time suspect (${riseTimeSec.toFixed(1)}s)`);
  }
  if (eventDuration > 20) {
    score += 3;
    flags.push(`durata lunga (${eventDuration.toFixed(0)}s)`);
  } else if (eventDuration > 8) {
    score += 1;
    flags.push(`durata medie (${eventDuration.toFixed(0)}s)`);
  } else if (eventDuration < 4) {
    score -= 4;
    flags.push(`durata SCURTA (${eventDuration.toFixed(1)}s) \u2014 probabil trafic`);
  } else if (eventDuration < 6) {
    score -= 2;
    flags.push(`durata redusa (${eventDuration.toFixed(1)}s)`);
  }
  if (codaRatio > 2.5) {
    score += 3;
    flags.push("coda seismica pronuntata");
  } else if (codaRatio > 1.5) {
    score += 1;
    flags.push("coda moderata");
  } else if (codaRatio < 0.9) {
    score -= 2;
    flags.push("fara coda (simetric)");
  }
  if (impulsivity > 20) {
    score -= 3;
    flags.push(`impuls izolat (x${impulsivity.toFixed(0)} RMS) \u2014 trafic`);
  } else if (impulsivity > 12) {
    score -= 1;
    flags.push("partial impulsiv");
  } else if (impulsivity < 6) {
    score += 1;
    flags.push("semnal gradual");
  }
  if (spectralPersistence > 0.6) {
    score += 2;
    flags.push("semnal persistent in timp");
  } else if (spectralPersistence < 0.25) {
    score -= 2;
    flags.push("semnal izolat (1-2 segmente)");
  }
  if (staLta.maxRatio > 12 && staLta.triggerDuration < 2) {
    score -= 3;
    flags.push("trigger STA/LTA scurt si puternic");
  } else if (staLta.maxRatio > 4 && staLta.triggerDuration > 8) {
    score += 2;
    flags.push("trigger STA/LTA sustinut");
  }
  if (ratioInfrasonic > 0.6) {
    score -= 6;
    flags.push(`infrason dominant (${(ratioInfrasonic * 100).toFixed(0)}% energie sub 0.5Hz) \u2014 deriva senzor/ADC`);
  } else if (ratioInfrasonic > 0.3) {
    score -= 3;
    flags.push("energie infrasonica ridicata \u2014 posibil zgomot de fond");
  }
  const peakAbsRaw = Math.max(...raw.map(Math.abs));
  if (peakAbsRaw > 15e8) {
    score -= 6;
    flags.push("posibila saturare ADC \u2014 amplitudine fizic imposibila");
  } else if (peakAbsRaw > 5e8) {
    score -= 3;
    flags.push("amplitudine suspect de mare \u2014 verifica senzorul");
  }
  const hardVetoTraffic = riseTimeSec < 0.5 && eventDuration < 3;
  const hardVetoEq = eventDuration > 30 && ratioSeismic > 0.4;
  if (hardVetoTraffic) score = Math.min(score, -3);
  if (hardVetoEq) score = Math.max(score, 4);
  let type, confidence;
  if (score >= 6) {
    type = "earthquake";
    confidence = Math.min(92, 65 + score * 2);
  } else if (score >= 3) {
    type = "possible_earthquake";
    confidence = Math.min(75, 45 + score * 5);
  } else if (score <= -4) {
    type = "traffic";
    confidence = Math.min(95, 65 + Math.abs(score) * 3);
  } else if (score <= -2) {
    type = "noise";
    confidence = Math.min(80, 50 + Math.abs(score) * 5);
  } else {
    type = "ambient";
    confidence = 50;
  }
  return {
    type,
    confidence: Math.round(confidence),
    score,
    flags,
    // motive clasificare
    details: {
      ratioSeismic: Math.round(ratioSeismic * 100),
      ratioTraffic: Math.round(ratioTraffic * 100),
      ratioIndustrial: Math.round(ratioIndustrial * 100),
      ratioInfrasonic: Math.round(ratioInfrasonic * 100),
      riseTimeSec: Math.round(riseTimeSec * 10) / 10,
      eventDuration: Math.round(eventDuration * 10) / 10,
      codaRatio: Math.round(codaRatio * 100) / 100,
      impulsivity: Math.round(impulsivity * 10) / 10,
      spectralPersistence: Math.round(spectralPersistence * 100),
      staLtaMax: Math.round(staLta.maxRatio * 10) / 10,
      staLtaDuration: Math.round(staLta.triggerDuration * 10) / 10,
      asymmetry: Math.round(asymmetry * 100)
    }
  };
}
function computeEnvelope(signal, fs) {
  const abs = signal.map(Math.abs);
  const w = Math.max(3, Math.round(fs * 0.5));
  const env = new Array(abs.length).fill(0);
  for (let i = 0; i < abs.length; i++) {
    let sum = 0, cnt = 0;
    for (let j = Math.max(0, i - w); j <= Math.min(abs.length - 1, i + w); j++) {
      sum += abs[j];
      cnt++;
    }
    env[i] = sum / cnt;
  }
  return env;
}
function computeSTALTA(signal, fs) {
  const staWin = Math.round(fs * 1);
  const ltaWin = Math.round(fs * 30);
  const threshold = 3;
  let maxRatio = 0;
  let triggerCount = 0;
  for (let i = ltaWin; i < signal.length; i++) {
    let sta = 0, lta = 0;
    for (let j = i - staWin; j < i; j++) sta += signal[j] * signal[j];
    for (let j = i - ltaWin; j < i - staWin; j++) lta += signal[j] * signal[j];
    sta /= staWin;
    lta /= ltaWin - staWin;
    if (lta > 0) {
      const ratio = sta / lta;
      if (ratio > maxRatio) maxRatio = ratio;
      if (ratio > threshold) triggerCount++;
    }
  }
  return {
    maxRatio,
    triggerDuration: triggerCount / fs
  };
}
function nextPow2(n) {
  let p = 1;
  while (p < n) p <<= 1;
  return p;
}
function fftInPlace(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = -2 * Math.PI / len;
    const wR = Math.cos(ang), wI = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cR = 1, cI = 0;
      for (let j = 0; j < len / 2; j++) {
        const uR = re[i + j], uI = im[i + j];
        const vR = re[i + j + len / 2] * cR - im[i + j + len / 2] * cI;
        const vI = re[i + j + len / 2] * cI + im[i + j + len / 2] * cR;
        re[i + j] = uR + vR;
        im[i + j] = uI + vI;
        re[i + j + len / 2] = uR - vR;
        im[i + j + len / 2] = uI - vI;
        const nr = cR * wR - cI * wI;
        cI = cR * wI + cI * wR;
        cR = nr;
      }
    }
  }
}
function decodeMiniSEED(buf) {
  const allSamples = [];
  let sampleRate = 100;
  let startTime = null;
  let offset = 0;
  while (offset + 64 <= buf.length) {
    const indicator = String.fromCharCode(buf[offset + 6]);
    if (!"DRQM".includes(indicator)) {
      offset += 512;
      continue;
    }
    const view = new DataView(buf.buffer, buf.byteOffset + offset, buf.length - offset);
    const year = view.getUint16(20, false);
    const dayOfYear = view.getUint16(22, false);
    const hour = view.getUint8(24);
    const min = view.getUint8(25);
    const sec = view.getUint8(26);
    const frac = view.getUint16(28, false);
    if (!startTime && year > 2e3 && year < 2100) {
      const d = new Date(Date.UTC(year, 0, 1));
      d.setUTCDate(dayOfYear);
      d.setUTCHours(hour, min, sec, Math.round(frac / 10));
      startTime = d.toISOString();
    }
    const numSamples = view.getUint16(30, false);
    const srateFactor = view.getInt16(32, false);
    const srateMulti = view.getInt16(34, false);
    const blkOffset0 = view.getUint16(46, false);
    const dataOffsetH = view.getUint16(44, false);
    if (srateFactor > 0 && srateMulti > 0) sampleRate = srateFactor * srateMulti;
    else if (srateFactor > 0 && srateMulti < 0) sampleRate = -srateFactor / srateMulti;
    else if (srateFactor < 0 && srateMulti > 0) sampleRate = -srateMulti / srateFactor;
    else if (srateFactor < 0 && srateMulti < 0) sampleRate = 1 / (srateFactor * srateMulti);
    let dataEncoding = 11;
    let recLength = 9;
    let dataStart = dataOffsetH || 64;
    let blkOff = blkOffset0;
    for (let b = 0; b < 10 && blkOff > 0 && blkOff + 8 < 512; b++) {
      const blkType = view.getUint16(blkOff, false);
      const nextBlk = view.getUint16(blkOff + 2, false);
      if (blkType === 1e3) {
        dataEncoding = view.getUint8(blkOff + 4);
        recLength = view.getUint8(blkOff + 6);
        dataStart = dataOffsetH;
        break;
      }
      if (nextBlk === 0 || nextBlk <= blkOff) break;
      blkOff = nextBlk;
    }
    const recBytes = 1 << recLength;
    if (recBytes < 64 || offset + recBytes > buf.length) {
      offset += 512;
      continue;
    }
    const dataView = new DataView(buf.buffer, buf.byteOffset + offset);
    try {
      let recSamples = [];
      if (dataEncoding === 11) recSamples = decodeSteim2(dataView, dataStart, recBytes, numSamples);
      else if (dataEncoding === 10) recSamples = decodeSteim1(dataView, dataStart, recBytes, numSamples);
      else if (dataEncoding === 3) recSamples = decodeInt32(dataView, dataStart, recBytes, numSamples);
      else if (dataEncoding === 1) recSamples = decodeInt16(dataView, dataStart, recBytes, numSamples);
      allSamples.push(...recSamples);
    } catch (_) {
    }
    offset += recBytes;
  }
  return { samples: allSamples, sampleRate, startTime };
}
function decodeSteim1(view, dataStart, recBytes, numSamples) {
  const diffs = [];
  let x0 = null;
  let frameOffset = dataStart;
  while (frameOffset + 64 <= recBytes && diffs.length < numSamples) {
    const ctrl = view.getUint32(frameOffset, false);
    for (let w = 0; w < 16 && diffs.length < numSamples; w++) {
      const code = ctrl >>> 30 - w * 2 & 3;
      if (w === 0 && frameOffset === dataStart) {
        x0 = view.getInt32(frameOffset + 4, false);
        continue;
      }
      if (w === 0) continue;
      const word = view.getInt32(frameOffset + w * 4, false);
      if (code === 0) continue;
      else if (code === 1) {
        for (let b = 3; b >= 0 && diffs.length < numSamples; b--) {
          const v = word >> b * 8 & 255;
          diffs.push(v > 127 ? v - 256 : v);
        }
      } else if (code === 2) {
        for (let b = 1; b >= 0 && diffs.length < numSamples; b--) {
          const v = word >> b * 16 & 65535;
          diffs.push(v > 32767 ? v - 65536 : v);
        }
      } else if (code === 3) {
        diffs.push(word);
      }
    }
    frameOffset += 64;
  }
  if (x0 !== null && diffs.length > 0) {
    const out = [x0];
    for (let i = 1; i < diffs.length; i++) out.push(out[i - 1] + diffs[i]);
    return out.slice(0, numSamples);
  }
  return diffs.slice(0, numSamples);
}
function decodeSteim2(view, dataStart, recBytes, numSamples) {
  const diffs = [];
  let x0 = null;
  let frameOffset = dataStart;
  while (frameOffset + 64 <= recBytes && diffs.length < numSamples) {
    const ctrl = view.getUint32(frameOffset, false);
    for (let w = 0; w < 16 && diffs.length < numSamples; w++) {
      const dnib = ctrl >>> 30 - w * 2 & 3;
      if (w === 0) {
        if (frameOffset === dataStart) x0 = view.getInt32(frameOffset + 4, false);
        continue;
      }
      if (dnib === 0) continue;
      const word = view.getUint32(frameOffset + w * 4, false);
      if (dnib === 1) {
        diffs.push(word | 0);
      } else if (dnib === 2) {
        const cnib = word >>> 30 & 3;
        if (cnib === 0) {
          diffs.push(sign30(word & 1073741823));
        } else if (cnib === 1) {
          diffs.push(sign15(word >>> 15 & 32767));
          if (diffs.length < numSamples) diffs.push(sign15(word & 32767));
        } else if (cnib === 2) {
          diffs.push(sign10(word >>> 20 & 1023));
          if (diffs.length < numSamples) diffs.push(sign10(word >>> 10 & 1023));
          if (diffs.length < numSamples) diffs.push(sign10(word & 1023));
        } else {
          for (let i = 4; i >= 0 && diffs.length < numSamples; i--)
            diffs.push(sign6(word >>> i * 6 & 63));
        }
      } else if (dnib === 3) {
        const cnib = word >>> 30 & 3;
        if (cnib === 0) {
          for (let i = 5; i >= 0 && diffs.length < numSamples; i--)
            diffs.push(sign5(word >>> i * 5 & 31));
        } else if (cnib === 1) {
          for (let i = 6; i >= 0 && diffs.length < numSamples; i--)
            diffs.push(sign4(word >>> i * 4 & 15));
        }
      }
    }
    frameOffset += 64;
  }
  if (x0 !== null && diffs.length > 0) {
    const out = new Array(Math.min(diffs.length, numSamples));
    out[0] = x0;
    for (let i = 1; i < out.length; i++) out[i] = out[i - 1] + diffs[i];
    return out;
  }
  return diffs.slice(0, numSamples);
}
function decodeInt32(view, ds, rb, n) {
  const out = [];
  for (let i = 0; i < n && ds + i * 4 + 4 <= rb; i++) out.push(view.getInt32(ds + i * 4, false));
  return out;
}
function decodeInt16(view, ds, rb, n) {
  const out = [];
  for (let i = 0; i < n && ds + i * 2 + 2 <= rb; i++) out.push(view.getInt16(ds + i * 2, false));
  return out;
}
function sign30(v) {
  return v & 536870912 ? v - 1073741824 : v;
}
function sign15(v) {
  return v & 16384 ? v - 32768 : v;
}
function sign10(v) {
  return v & 512 ? v - 1024 : v;
}
function sign6(v) {
  return v & 32 ? v - 64 : v;
}
function sign5(v) {
  return v & 16 ? v - 32 : v;
}
function sign4(v) {
  return v & 8 ? v - 16 : v;
}
function corsHeaders() {
  return { "Access-Control-Allow-Origin": "*", "Cache-Control": "no-cache" };
}
function json400(b) {
  return { statusCode: 400, headers: { ...corsHeaders(), "Content-Type": "application/json" }, body: JSON.stringify(b) };
}
function json500(b) {
  return { statusCode: 500, headers: { ...corsHeaders(), "Content-Type": "application/json" }, body: JSON.stringify(b) };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
